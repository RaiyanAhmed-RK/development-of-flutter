package com.example.app_004

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
