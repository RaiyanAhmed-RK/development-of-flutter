package com.example.app_001

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
