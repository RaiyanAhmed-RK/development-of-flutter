package com.example.app_003

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
