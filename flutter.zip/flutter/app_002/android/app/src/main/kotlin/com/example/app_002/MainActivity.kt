package com.example.app_002

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
